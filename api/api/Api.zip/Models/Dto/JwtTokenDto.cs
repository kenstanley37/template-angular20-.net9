﻿namespace api.Models.Dto
{
    public class JwtTokenDto
    {
        public string Token { get; set; } = string.Empty;
    }
}
