﻿namespace api.Models.Dto
{
    public class UpdateProfilePictureDto
    {
        public string? ProfilePicture { get; set; }
    }
}
