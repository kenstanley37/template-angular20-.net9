﻿namespace api.Models.Dto
{
    public class SocialLoginDto
    {
        public string Token { get; set; } = string.Empty;
        public bool StayLoggedIn { get; set; }
    }
}
