﻿using System.Text.Json.Serialization;

namespace api.Models
{
    public class TokenPayloads
    {
        public class GoogleTokenPayload
        {
            [JsonPropertyName("email")]
            public string? Email { get; set; }

            [JsonPropertyName("sub")]
            public string? Sub { get; set; }

            [JsonPropertyName("name")]
            public string? Name { get; set; }

            [JsonPropertyName("picture")]
            public string? Picture { get; set; }
        }

        public class FacebookTokenPayload
        {
            [JsonPropertyName("email")]
            public string? Email { get; set; }

            [JsonPropertyName("id")]
            public string? Id { get; set; }

            [JsonPropertyName("name")]
            public string? Name { get; set; }

            [JsonPropertyName("picture")]
            public PictureData? Picture { get; set; }
        }

        public class PictureData
        {
            [JsonPropertyName("data")]
            public PictureUrl? Data { get; set; }
        }

        public class PictureUrl
        {
            [JsonPropertyName("url")]
            public string? Url { get; set; }
        }

        public class FacebookDebugTokenResponse
        {
            [JsonPropertyName("data")]
            public FacebookDebugTokenData? Data { get; set; }
        }

        public class FacebookDebugTokenData
        {
            [JsonPropertyName("is_valid")]
            public bool IsValid { get; set; }
        }
    }
}
