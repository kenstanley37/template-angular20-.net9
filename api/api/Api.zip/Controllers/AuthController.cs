﻿using api.Data;
using api.Models;
using api.Models.Dto;
using Azure.Core;
using Google.Apis.Auth;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Net.Mail;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using static api.Models.TokenPayloads;

namespace api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly AuthDbContext _context;
        private readonly IConfiguration _configuration;
        private readonly HttpClient _httpClient;

        public AuthController(AuthDbContext context, IConfiguration configuration, IHttpClientFactory httpClientFactory)
        {
            _context = context;
            _configuration = configuration;
            _httpClient = httpClientFactory.CreateClient();
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterDto dto)
        {
            if (await _context.Users.AnyAsync(u => u.Email == dto.Email))
            {
                return BadRequest("Email already exists.");
            }

            var verificationToken = Guid.NewGuid().ToString();
            var user = new User
            {
                Name = dto.Name,
                Email = dto.Email,
                PasswordHash = BCrypt.Net.BCrypt.HashPassword(dto.Password),
                EmailVerificationToken = verificationToken
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            await SendVerificationEmail(user.Email, verificationToken);

            return Ok("User registered successfully. Please check your email to verify your account.");
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginDto dto)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == dto.Email);
            if (user == null || !BCrypt.Net.BCrypt.Verify(dto.Password, user.PasswordHash))
            {
                return Unauthorized("Invalid credentials.");
            }

            if (!user.IsEmailVerified)
            {
                return Unauthorized("Please verify your email before logging in.");
            }

            var token = GenerateJwtToken(user);
            SetAuthCookie(token);

            if (dto.StayLoggedIn)
            {
                var refreshToken = await GenerateRefreshToken(user);
                SetRefreshCookie(refreshToken.Token);
            }

            return Ok();
        }

        [HttpGet("verify-email")]
        public async Task<IActionResult> VerifyEmail([FromQuery] string token)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.EmailVerificationToken == token);
            if (user == null)
            {
                return BadRequest("Invalid verification token.");
            }

            user.IsEmailVerified = true;
            user.EmailVerificationToken = null;
            await _context.SaveChangesAsync();

            return Ok("Email verified successfully.");
        }

        [HttpPost("google-login")]
        public async Task<IActionResult> GoogleLogin([FromBody] SocialLoginDto authToken)
        {
            try
            {
                var settings = new GoogleJsonWebSignature.ValidationSettings
                {
                    Audience = new[] { _configuration["Google:ClientId"] }
                };

                var payload = await GoogleJsonWebSignature.ValidateAsync(authToken.Token, settings);

                //var payload = await ValidateGoogleToken(authToken.Token);
                if (payload == null)
                {
                    return BadRequest("Invalid Google token.");
                }

                if (string.IsNullOrEmpty(payload.Email) || string.IsNullOrEmpty(payload.Subject))
                {
                    return BadRequest("Invalid Google token payload: missing email or sub.");
                }

                var user = await _context.Users.FirstOrDefaultAsync(u => u.GoogleId == payload.Subject || u.Email == payload.Email);
                if (user == null)
                {
                    user = new User
                    {
                        Name = payload.Name,
                        Email = payload.Email,
                        GoogleId = payload.Subject,
                        ProfilePicture = payload.Picture,
                        IsEmailVerified = true
                    };
                    _context.Users.Add(user);
                }
                else if (string.IsNullOrEmpty(user.GoogleId))
                {
                    user.GoogleId = payload.Subject;
                    user.ProfilePicture = payload.Picture;
                    user.IsEmailVerified = true;
                }

                await _context.SaveChangesAsync();

                var token = GenerateJwtToken(user);
                SetAuthCookie(token);

                if (authToken.StayLoggedIn)
                {
                    var refreshToken = await GenerateRefreshToken(user);
                    SetRefreshCookie(refreshToken.Token);
                }

                var profile = new ProfileDto()
                {
                    Name = payload.Name,
                    Email = payload.Email,
                    Id = user.Id
                };

                return Ok(profile);
            }
            catch (InvalidJwtException)
            {
                return Unauthorized("Invalid Google token");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
            
        }

        [HttpPost("facebook-login")]
        public async Task<IActionResult> FacebookLogin([FromBody] SocialLoginDto authToken)
        {
            try
            {
                var payload = await ValidateFacebookToken(authToken.Token);
                if (payload == null)
                {
                    return BadRequest("Invalid Facebook token.");
                }

                if (string.IsNullOrEmpty(payload.Email) || string.IsNullOrEmpty(payload.Id))
                {
                    return BadRequest("Invalid Facebook token payload: missing email or id.");
                }

                var user = await _context.Users.FirstOrDefaultAsync(u => u.FacebookId == payload.Id || u.Email == payload.Email);
                if (user == null)
                {
                    user = new User
                    {
                        Name = payload.Name!,
                        Email = payload.Email,
                        FacebookId = payload.Id,
                        ProfilePicture = payload.Picture?.Data?.Url,
                        IsEmailVerified = true
                    };
                    _context.Users.Add(user);
                }
                else if (string.IsNullOrEmpty(user.FacebookId))
                {
                    user.FacebookId = payload.Id;
                    user.ProfilePicture = payload.Picture?.Data?.Url;
                    user.IsEmailVerified = true;
                }

                await _context.SaveChangesAsync();

                var token = GenerateJwtToken(user);
                SetAuthCookie(token);

                if (authToken.StayLoggedIn)
                {
                    var refreshToken = await GenerateRefreshToken(user);
                    SetRefreshCookie(refreshToken.Token);
                }

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPost("refresh")]
        public async Task<IActionResult> Refresh()
        {
            var refreshToken = Request.Cookies["refresh_token"];
            if (string.IsNullOrEmpty(refreshToken))
            {
                return Unauthorized("No refresh token provided.");
            }

            var tokenEntity = await _context.RefreshTokens
                .Include(t => t.User)
                .FirstOrDefaultAsync(t => t.Token == refreshToken && !t.IsRevoked && t.Expires > DateTime.UtcNow);

            if (tokenEntity == null)
            {
                Response.Cookies.Delete("refresh_token");
                return Unauthorized("Invalid or expired refresh token.");
            }

            var newJwt = GenerateJwtToken(tokenEntity.User);
            SetAuthCookie(newJwt);

            return Ok();
        }

        [HttpPost("logout")]
        public async Task<IActionResult> Logout()
        {
            var refreshToken = Request.Cookies["refresh_token"];
            if (!string.IsNullOrEmpty(refreshToken))
            {
                var tokenEntity = await _context.RefreshTokens.FirstOrDefaultAsync(t => t.Token == refreshToken);
                if (tokenEntity != null)
                {
                    tokenEntity.IsRevoked = true;
                    await _context.SaveChangesAsync();
                }
                Response.Cookies.Delete("refresh_token");
            }

            Response.Cookies.Delete("auth_token");
            return Ok();
        }

        [HttpGet("profile")]
        public async Task<IActionResult> GetProfile()
        {
            var token = Request.Cookies["auth_token"];
            string? email;

            if (string.IsNullOrEmpty(token) || string.IsNullOrEmpty(email = ValidateJwtToken(token)))
            {
                var refreshResult = await TryRefreshToken();
                if (refreshResult != null)
                {
                    return refreshResult;
                }
                Response.Cookies.Delete("auth_token");
                return Unauthorized("User not authenticated.");
            }

            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == email);
            if (user == null)
            {
                return NotFound("User not found.");
            }

            return Ok(new ProfileDto
            {
                Name = user.Name,
                Email = user.Email,
                ProfilePicture = user.ProfilePicture
            });
        }

        [HttpPost("profile/picture")]
        public async Task<IActionResult> UpdateProfilePicture([FromBody] UpdateProfilePictureDto dto)
        {
            var token = Request.Cookies["auth_token"];
            string? email;

            if (string.IsNullOrEmpty(token) || string.IsNullOrEmpty(email = ValidateJwtToken(token)))
            {
                var refreshResult = await TryRefreshToken();
                if (refreshResult != null)
                {
                    return refreshResult;
                }
                Response.Cookies.Delete("auth_token");
                return Unauthorized("User not authenticated.");
            }

            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == email);
            if (user == null)
            {
                return NotFound("User not found.");
            }

            if (!string.IsNullOrEmpty(dto.ProfilePicture) && !IsValidBase64Image(dto.ProfilePicture))
            {
                return BadRequest("Invalid image format. Must be a valid Base64-encoded image (JPEG or PNG).");
            }

            user.ProfilePicture = dto.ProfilePicture;
            await _context.SaveChangesAsync();

            return Ok("Profile picture updated successfully.");
        }

        private async Task<IActionResult?> TryRefreshToken()
        {
            var refreshToken = Request.Cookies["refresh_token"];
            if (string.IsNullOrEmpty(refreshToken))
            {
                return null;
            }

            var tokenEntity = await _context.RefreshTokens
                .Include(t => t.User)
                .FirstOrDefaultAsync(t => t.Token == refreshToken && !t.IsRevoked && t.Expires > DateTime.UtcNow);

            if (tokenEntity == null)
            {
                Response.Cookies.Delete("refresh_token");
                return Unauthorized("Invalid or expired refresh token.");
            }

            var newJwt = GenerateJwtToken(tokenEntity.User);
            SetAuthCookie(newJwt);

            return null; // Continue with original request
        }

        private void SetAuthCookie(string token)
        {
            var cookieOptions = new CookieOptions
            {
                HttpOnly = true,
                Secure = true,
                SameSite = SameSiteMode.Strict,
                Path = "/",
                Expires = DateTime.UtcNow.AddHours(1)
            };
            Response.Cookies.Append("auth_token", token, cookieOptions);
        }

        private void SetRefreshCookie(string token)
        {
            var cookieOptions = new CookieOptions
            {
                HttpOnly = true,
                Secure = true,
                SameSite = SameSiteMode.Strict,
                Path = "/",
                Expires = DateTime.UtcNow.AddDays(30)
            };
            Response.Cookies.Append("refresh_token", token, cookieOptions);
        }

        private async Task<RefreshToken> GenerateRefreshToken(User user)
        {
            var refreshToken = new RefreshToken
            {
                UserId = user.Id,
                Token = Guid.NewGuid().ToString(),
                Expires = DateTime.UtcNow.AddDays(30),
                IsRevoked = false
            };

            _context.RefreshTokens.Add(refreshToken);
            await _context.SaveChangesAsync();

            return refreshToken;
        }

        private string? ValidateJwtToken(string token)
        {
            var jwtKey = _configuration["Jwt:Key"] ?? throw new InvalidOperationException("Jwt:Key not found.");
            var jwtIssuer = _configuration["Jwt:Issuer"] ?? throw new InvalidOperationException("Jwt:Issuer not found.");
            var jwtAudience = _configuration["Jwt:Audience"] ?? throw new InvalidOperationException("Jwt:Audience not found.");

            var tokenHandler = new JwtSecurityTokenHandler();
            try
            {
                tokenHandler.ValidateToken(token, new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true,
                    ValidIssuer = jwtIssuer,
                    ValidAudience = jwtAudience,
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey))
                }, out var validatedToken);

                var jwtToken = validatedToken as JwtSecurityToken;
                return jwtToken?.Claims.FirstOrDefault(c => c.Type == JwtRegisteredClaimNames.Sub)?.Value;
            }
            catch
            {
                return null;
            }
        }

        private bool IsValidBase64Image(string base64String)
        {
            if (string.IsNullOrEmpty(base64String))
            {
                return true; // Allow empty to clear picture
            }

            try
            {
                if (!base64String.StartsWith("data:image/"))
                {
                    return false;
                }

                var parts = base64String.Split(',');
                if (parts.Length != 2)
                {
                    return false;
                }

                var mimeType = parts[0].Split(';')[0].Replace("data:", "");
                if (mimeType != "image/jpeg" && mimeType != "image/png")
                {
                    return false;
                }

                Convert.FromBase64String(parts[1]);
                return true;
            }
            catch
            {
                return false;
            }
        }

        private string GenerateJwtToken(User user)
        {
            var jwtKey = _configuration["Jwt:Key"] ?? throw new InvalidOperationException("Jwt:Key not found.");
            var jwtIssuer = _configuration["Jwt:Issuer"] ?? throw new InvalidOperationException("Jwt:Issuer not found.");
            var jwtAudience = _configuration["Jwt:Audience"] ?? throw new InvalidOperationException("Jwt:Audience not found.");

            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
                new Claim(JwtRegisteredClaimNames.Sub, user.Email),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim(ClaimTypes.Name, user.Name)
            };

            var token = new JwtSecurityToken(
                issuer: jwtIssuer,
                audience: jwtAudience,
                claims: claims,
                expires: DateTime.UtcNow.AddHours(1),
                signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        private async Task SendVerificationEmail(string email, string token)
        {
            var smtpHost = _configuration["Smtp:Host"];
            var smtpPort = int.Parse(_configuration["Smtp:Port"]!);
            var smtpUsername = _configuration["Smtp:Username"]?.ToString() ?? throw new InvalidOperationException("Invalid Smtp email address.");
            var smtpPassword = _configuration["Smtp:Password"]?.ToString() ?? throw new InvalidOperationException("Invalid Smtp password.");

            var frontendUrl = _configuration["Frontend:Url"]?.ToString() ?? throw new InvalidOperationException("Frontend:Url not found.");
            var verificationLink = $"{frontendUrl}/verify-email?token={token}";

            var message = new MailMessage
            {
                From = new MailAddress(smtpUsername),
                Subject = "Verify Your Email",
                Body = $"<p>Please verify your email by clicking the link below:</p><a href=\"{verificationLink}\">Verify Email</a>",
                IsBodyHtml = true
            };
            message.To.Add(email);

            using var smtp = new SmtpClient(smtpHost, smtpPort)
            {
                Credentials = new NetworkCredential(smtpUsername, smtpPassword),
                EnableSsl = true
            };

            await smtp.SendMailAsync(message);
        }

        private async Task<GoogleTokenPayload?> ValidateGoogleToken(string token)
        {
            var response = await _httpClient.GetAsync($"https://www.googleapis.com/oauth2/v3/tokeninfo?id_token={token}");
            if (!response.IsSuccessStatusCode)
            {
                return null;
            }

            var content = await response.Content.ReadAsStringAsync();
            try
            {
                return JsonSerializer.Deserialize<GoogleTokenPayload>(content, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (JsonException)
            {
                return null;
            }
        }

        private async Task<FacebookTokenPayload?> ValidateFacebookToken(string token)
        {
            var appId = _configuration["Facebook:AppId"]?.ToString() ?? throw new InvalidOperationException("Facebook:AppId not found.");
            var appSecret = _configuration["Facebook:AppSecret"]?.ToString() ?? throw new InvalidOperationException("Facebook: invalid AppSecret or not found.");
            var response = await _httpClient.GetAsync($"https://graph.facebook.com/debug_token?input_token={token}&access_token={appId}|{appSecret}");
            if (!response.IsSuccessStatusCode)
            {
                return null;
            }

            var content = await response.Content.ReadAsStringAsync();
            try
            {
                var debugToken = JsonSerializer.Deserialize<FacebookDebugTokenResponse>(content, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
                if (debugToken?.Data?.IsValid != true)
                {
                    return null;
                }
            }
            catch (JsonException)
            {
                return null;
            }

            var userResponse = await _httpClient.GetAsync($"https://graph.facebook.com/me?fields=id,name,email,picture&access_token={token}");
            if (!userResponse.IsSuccessStatusCode)
            {
                return null;
            }

            var userContent = await userResponse.Content.ReadAsStringAsync();
            try
            {
                return JsonSerializer.Deserialize<FacebookTokenPayload>(userContent, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (JsonException)
            {
                return null;
            }
        }
    }
}

