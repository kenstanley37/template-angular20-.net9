﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ConfigController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public ConfigController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet]
        public IActionResult Get()
        {
            var config = new
            {
                GoogleClientId = _configuration["Google:ClientId"],
                FacebookAppId = _configuration["Facebook:AppId"]
            };
            return Ok(config);
        }
    }
}
