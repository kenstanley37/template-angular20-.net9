import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Toolbar } from './_components/toolbar/toolbar';
import { AuthService } from './_services/auth-service';
import { catchError, switchMap, throwError } from 'rxjs';
@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Toolbar],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App {
  protected title = 'web';

  constructor(private authService: AuthService) {
    // Initialization logic can go here if needed
    this.refreshToken();
  }

  refreshToken() {
    // This method can be used to manually refresh the token if needed
    // Typically, this is handled by the auth interceptor automatically
    this.authService.refreshToken().subscribe({
      next: () => console.log('Token refreshed successfully'),
      error: (err) => console.error('Error refreshing token:', err)
    });
  }
}
