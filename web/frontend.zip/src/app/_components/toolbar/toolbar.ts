import { Component, inject } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { AuthService } from '../../_services/auth-service';
import { Observable } from 'rxjs';
import { ProfileDto } from '../../_models/user-model';
import { MatMenuModule } from '@angular/material/menu';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-toolbar',
  standalone: true,
  imports: [
    RouterModule,
    MatToolbarModule,
    MatButtonModule,
    MatIconModule,
    MatMenuModule,
    CommonModule
  ],
  templateUrl: './toolbar.html',
  styleUrl: './toolbar.scss'
})
export class Toolbar {
  private authService = inject(AuthService);
  private router = inject(Router);
  isAuthenticated$: boolean = false;
  profile: ProfileDto | null = null;


  constructor() {
    // Automatically fetch profile on initialization

    this.authService.isAuthenticated$.subscribe(isAuthenticated => {
      this.isAuthenticated$ = isAuthenticated;
    });

    this.authService.getProfile().subscribe({
      next: (profile) => this.profile = profile,
      error: (err) => console.error('Error fetching profile:', err)
    });
  }

  logout() {
    this.authService.logout().subscribe({
      next: () => this.router.navigate(['/login']),
      error: (err) => console.error('Logout failed:', err)
    });
  }
}