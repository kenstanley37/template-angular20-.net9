export interface JwtToken {
  token: string;
}