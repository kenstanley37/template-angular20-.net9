import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { BehaviorSubject, catchError, map, Observable, tap, throwError } from 'rxjs';
import { RegisterDto, LoginDto, ProfileDto, UpdateProfilePictureDto, SocialLoginDto } from '../_models/user-model';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private http = inject(HttpClient);
  private isAuthenticatedSubject = new BehaviorSubject<boolean>(false);
  private userProfileSubject = new BehaviorSubject<ProfileDto | null>(null);
  isAuthenticated$ = this.isAuthenticatedSubject.asObservable();
  userProfile$ = this.userProfileSubject.asObservable();

  register(dto: RegisterDto): Observable<any> {
    return this.http.post(`${environment.apiUrl}/auth/register`, dto, { withCredentials: true }).pipe(
      catchError(this.handleError)
    );
  }

  login(dto: LoginDto): Observable<any> {
    return this.http.post(`${environment.apiUrl}/auth/login`, dto, { withCredentials: true }).pipe(
      tap(() => this.isAuthenticatedSubject.next(true)),
      catchError(this.handleError)
    );
  }

  socialLogin(endpoint: string, dto: SocialLoginDto): Observable<any> {
    return this.http.post<ProfileDto>(`${environment.apiUrl}/auth/${endpoint}`, dto, { withCredentials: true }).pipe(
      tap(() => this.isAuthenticatedSubject.next(true)),
    
      catchError(this.handleError)
    );
  }

  getProfile(): Observable<ProfileDto> {
    console.log('Fetching profile from:', `${environment.apiUrl}/auth/profile`); // Debug
    return this.http.get<ProfileDto>(`${environment.apiUrl}/auth/profile`, { withCredentials: true }).pipe(
      tap(profile => {
        this.userProfileSubject.next(profile);
      })
    ).pipe(
      catchError((error: HttpErrorResponse) => {
        this.userProfileSubject.next(null);
        return this.handleError(error);
      })
    );
  }

 updateProfilePicture(dto: UpdateProfilePictureDto): Observable<any> {
    return this.http.post(`${environment.apiUrl}/auth/profile/picture`, dto, { withCredentials: true }).pipe(
      catchError(this.handleError)
    );
  }

  logout(): Observable<any> {
    return this.http.post(`${environment.apiUrl}/auth/logout`, {}, { withCredentials: true }).pipe(
      tap(() => {
        this.isAuthenticatedSubject.next(false);
      }),
      catchError(this.handleError)
    );
  }

  refreshToken(): Observable<any> {
    return this.http.post(`${environment.apiUrl}/auth/refresh`, {}, { withCredentials: true }).pipe(
      tap((response) => {
        this.isAuthenticatedSubject.next(true);
        this.getProfile();
        console.log('Token refreshed successfully:', response);
      }),
      catchError(error => {
        this.isAuthenticatedSubject.next(false);
        return this.handleError(error);
      })
    );
  }

  isLoggedIn(): boolean {
    return this.isAuthenticatedSubject.value;
  }
  private handleError(error: HttpErrorResponse): Observable<never> {
    let errorMessage = 'An error occurred. Please try again later.';
    if (error.status === 0) {
      errorMessage = `Unable to connect to the backend at ${environment.apiUrl}. Please check your connection.`;
    } else if (error.error instanceof ErrorEvent) {
      errorMessage = `Client error: ${error.error.message}`;
    } else {
      errorMessage = error.error || errorMessage;
    }
    console.error('AuthService error:', error);
    return throwError(() => new Error(errorMessage));
  }
}