import { Component, inject, OnInit, signal } from '@angular/core';
import { AuthService } from '../../../_services/auth-service';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators, FormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { Router, RouterLink, RouterModule } from '@angular/router';
import { SocialAuthService, FacebookLoginProvider, SocialUser, GoogleSigninButtonModule, GoogleLoginProvider } from '@abacritt/angularx-social-login';
import { LoginDto, SocialLoginDto } from '../../../_models/user-model';
import { GoogleAuthService } from '../../../_services/google-auth-service';


@Component({
  selector: 'app-login',
  imports: [
    ReactiveFormsModule,
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatCardModule,
    RouterModule,
    RouterLink,
    MatCheckboxModule,
    GoogleSigninButtonModule

  ],
  templateUrl: './login.html',
  styleUrl: './login.scss'
})
export class Login implements OnInit {

  private fb = inject(FormBuilder);
  private authService = inject(AuthService);
  private socialAuthService = inject(SocialAuthService);
  private router = inject(Router);
  loginForm: FormGroup;
  errorMessage = '';

  constructor(private googleAuthService: GoogleAuthService) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required]],
      stayLoggedIn: [false]
    });

    this.socialAuthService.authState.subscribe({
      next: (user: SocialUser) => {
        if (user) {
          const endpoint = user.provider === 'GOOGLE' ? 'google-login' : 'facebook-login';
          const socialDto: SocialLoginDto = {
            token: user.idToken || user.authToken,
            stayLoggedIn: this.loginForm.get('stayLoggedIn')?.value
          };
          this.authService.socialLogin(endpoint, socialDto).subscribe({
            next: () => this.router.navigate(['/']),
            error: (err: Error) => this.errorMessage = err.message
          });
        }
      },
      error: (err: any) => this.errorMessage = 'Social login failed.'
    });
  }

  ngOnInit(): void {
    //For button login
    (globalThis as any).googleSignIn = (response: any) => {
      // Handle the response here
      console.log('Received credential response:', response);
      //api call or jwt decode or any other logics will go here

      console.log('ID: ' + response['clientId']); // Do not send to your backend! Use an ID token instead.
      console.log('Id2: ' + response['client_id']);
      console.log('Name: ' + response['credential'].getBasicProfile().getName());
      //console.log('Image URL: ' + profile.getImageUrl());
      //console.log('Email: ' + profile.getEmail()); // This is null if the 'email' scope is not present.

    };
  }

  onSubmit() {
    if (this.loginForm.invalid) {
      this.errorMessage = 'Please fill in all required fields correctly.';
      return;
    }

    const loginDto: LoginDto = this.loginForm.value;
    this.authService.login(loginDto).subscribe({
      next: () => this.router.navigate(['/']),
      error: (err: Error) => this.errorMessage = err.message
    });
  }

  triggerSignIn() {
    this.googleAuthService.promptSignIn();
  }

}
